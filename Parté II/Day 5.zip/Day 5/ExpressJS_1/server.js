const app = require("./index")

const PORT = process.env.PORT ?? 1200

app.listen(PORT, () => console.log(`Server started at http://172.0.0.1:${PORT}`))