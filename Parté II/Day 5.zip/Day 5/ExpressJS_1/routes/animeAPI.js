const { GET_ALL, GET, POST, DELETE, PATCH, PUT, GET_Validator, POST_Validator } = require("../route_handlers/handlers")
const express = require('express')

const animeAPI = express.Router()
animeAPI.param("id", (request, response, next, value) => { 
    console.log("id: "+ value)
    next()
})

animeAPI.route("/")
    .get(GET_ALL)
    .post(POST_Validator, POST)

animeAPI.route("/:id")
    .get(GET_Validator, GET)
    .delete(DELETE)
    .patch(PATCH)
    .put(PUT)

module.exports = animeAPI