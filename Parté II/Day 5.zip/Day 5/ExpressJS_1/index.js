const animeAPI = require("./routes/animeAPI")

const morgan = require('morgan')
const express = require('express')
const dotenv = require('dotenv')
const app = express()

dotenv.config({path: "./config.env"})

app.use(express.json())
app.use(morgan("dev"))

app.use("/api/v1/animes",animeAPI)

module.exports = app