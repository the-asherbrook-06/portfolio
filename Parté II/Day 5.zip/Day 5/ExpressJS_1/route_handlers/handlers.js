const fs = require('fs');
const path = require('path')

function GET_ALL(request, response) {
    try {
        const animeJSON = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "model/product.json"), "utf8"))
        response.status(200).json({
            status: "fulfilled",
            count: animeJSON.length,
            data: {
                animes: animeJSON
            }
        })
    } catch (err) {
        response.status(404).json({
            status: "failed",
            count: null,
            data: null
        })
    }
}

function GET_Validator(request, response, next, value) {
    const id = parseInt(value, 10); // Convert value to a number
    if (isNaN(id)) {
        // If not a valid number, return a 400 error
        return response.status(400).json({
            status: "failed",
            message: "ID invalid - Must be a numeric value",
            data: { id: value }
        });
    }

    // Check if the ID exists in the dataset
    const item = animeData.find(i => i.id === id);
    if (!item) {
        // If ID doesn't exist, return a 400 error
        return response.status(400).json({
            status: "failed",
            message: `ID invalid - No data found for ID: ${id}`,
            data: { id }
        });
    }

    // If everything is fine, proceed to the next middleware
    next();
}


function GET(request, response) {
    try {
        const animeJSON = JSON
            .parse(fs.readFileSync(path.join(__dirname, "..", "model/product.json"), "utf8"))
            .find((i) => { if (i.id == request.params.id) return true })
        response.status(200).json({
            status: "fulfiled",
            data: animeJSON
        })
    } catch (err) {
        response.status(404).json({
            status: "failed",
            data: null
        })
    }
}

function POST_Validator(request, response, next) {
    const body = request.body;
    const UserToken = request.query.Token;


    if (UserToken !== "TheServerIsProtected") {
        return response.status(401).json({
            status: "failed",
            message: "Unauthorized Access to Server",
        });
    }

    if (!Array.isArray(body) || body.length === 0) {
        return response.status(400).json({
            status: "failed",
            message: "Bad Request - Body must be a non-empty array.",
        });
    }

    body.forEach((anime) => {
        if (!anime.name || !anime.episodeCount) return response.status(400).json({
            status: "failed",
            message: `Bad Request - Missing required fields in item at index ${i}.`,
            data: body,
        })
    })

    next();
}

function POST(request, response) {
    try {
        const animeJSON = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "model/product.json"), "utf8"))
        const maxId = animeJSON.reduce((max, anime) => Math.max(max, anime.id || 0), 0)
        const newAnimeJSON = request.body.map((anime, index) => ({
            id: maxId + 1 + index,
            name: anime.name,
            episodeCount: anime.episodeCount,
        }))
        animeJSON.push(...newAnimeJSON);

        fs.writeFileSync(path.join(__dirname, "..", "model/product.json"), JSON.stringify(animeJSON, null, 2))

        response.status(200).json({
            status: "fulfilled",
            message: "PUSHED Data Successfully",
        })
    } catch (err) {
        response.status(500).json({
            status: "failed",
            message: "Failed to PUSH Data",
        })
    }
}

function DELETE(request, response) {
    let id = parseInt(request.params.id)

    try {
        const animeJSON = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "model/product.json"), "utf8"))
        const newAnimeJSON = animeJSON.filter((i) => i.id != id)
        fs.writeFileSync(path.join(__dirname, "..", "model/product.json"), JSON.stringify(newAnimeJSON, null, 2))

        response.status(200).json({
            status: "fulfiled",
            message: "DELETED Sucessfully"
        })
    } catch (err) {
        response.status(500).json({
            status: "failed",
            message: "Failed to DELETE Data",
        })
    }
}

function PATCH(request, response) {
    let id = request.params.id * 1
    let body = request.body

    try {
        const animeJSON = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "model/product.json"), "utf8"))
        const updateAnimeJSON = animeJSON.find((i) => i.id === id)
        const index = animeJSON.indexOf(updateAnimeJSON)

        animeJSON[index] = Object.assign(updateAnimeJSON, body)
        fs.writeFileSync(path.join(__dirname, "..", "model/product.json"), JSON.stringify(animeJSON, null, 2))

        response.status(200)
        response.json({
            status: "fulfiled",
            message: "Value PATCHED",
            data: updateAnimeJSON
        })
    } catch (err) {
        response.status(500)
        response.json({
            status: "failed",
            message: "Value not PATCHED",
            data: null
        })
    }
}

function PUT(request, response) {
    let id = request.params.id * 1
    let body = request.body

    try {
        const animeJSON = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "model/product.json"), "utf8"))
        const index = animeJSON.indexOf(animeJSON.find((i) => i.id === id))

        animeJSON[index] = body
        fs.writeFileSync(path.join(__dirname, "..", "model/product.json"), JSON.stringify(animeJSON, null, 2))

        response.status(200)
        response.json({
            status: "fulfilled",
            message: "Value PUT sucessfully",
            data: body
        })
    } catch (err) {
        response.status(500)
        response.json({
            status: "failed",
            message: "Value failed to PUT",
            data: null
        })
    }
}

module.exports = { GET_ALL, GET, POST, DELETE, PATCH, PUT, GET_Validator, POST_Validator }