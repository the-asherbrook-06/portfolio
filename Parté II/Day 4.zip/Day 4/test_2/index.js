const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const { log } = console;

let template = fs.readFileSync(path.join(__dirname, 'template.html'), 'utf8');
let productJSON = JSON.parse(fs.readFileSync(path.join(__dirname, 'data/product.json'), 'utf8'))

let productTemplate = fs.readFileSync(path.join(__dirname, 'template/product.html'), 'utf8')
let product = productJSON.map((prod) => {
    return productTemplate
        .replace("{{%IMAGELINK%}}", prod.productImage)
        .replace("{{%NAME%}}", prod.name)
        .replace("{{%MODELNAME%}}", prod.modeName)
        .replace("{{%MODELNUMBER%}}", prod.modelNumber)
        .replace("{{%ROM%}}", prod.ROM)
        .replace("{{%SIZE%}}", prod.size)
        .replace("{{%CAMERA%}}", prod.camera)
        .replace("{{%DESCRIPTION%}}", prod.Description)
        .replace("{{%PRICE%}}", prod.price)
        .replace("{{%COLOR%}}", prod.color)
        .replace("{{%ID%}}", prod.id)
})

http.createServer((request, response) => {
    let urlPath = request.url;

    let { query } = url.parse(urlPath, true)
    log('id: ' + query.id)

    const routes = {
        '/home': fs.readFileSync(path.join(__dirname, 'template/home.html'), 'utf8'),
        '/about': fs.readFileSync(path.join(__dirname, 'template/about.html'), 'utf8'),
        '/contact': fs.readFileSync(path.join(__dirname, 'template/contact.html'), 'utf8'),
        '/product': product,
    };

    if (urlPath === '/') urlPath = '/home';

    if (query.id == undefined || routes[urlPath]) {
        response.writeHead(200, { 'Content-Type': 'text/html' });
        response.end(template.replace('{{%CONTENT%}}',Array.isArray(routes[urlPath]) ? routes[urlPath].join(" ") : routes[urlPath]));
    } else if (query.id != undefined || routes[urlPath]) {
        var data = routes['/product'][query.id].replace(
            `<a href="/product?id=${query.id}" class="btn btn-secondary">Show Details</a>`,
            "")
        log(data)
        response.writeHead(200, { 'Content-Type': 'text/html' });
        response.end(template.replace('{{%CONTENT%}}', data));
    } else {
        response.writeHead(404, { 'Content-Type': 'text/html' });
        response.end(template.replace('{{%CONTENT%}}', `Error 404. <br> ${urlPath} is not found`));
    }

}).listen(1000, () => log('Server started at http://127.0.0.1:1000'))