import { log } from 'console'
import { createServer } from 'http'
import { readFileSync } from 'fs'

createServer((request, response) => {
    let path = request.url

    if (path === "/" || path === "/home") {
        response.writeHead(200, { "ContentType": "text/html" })
        response.end(readFileSync('pages/home.html', 'utf8'))
    } 
    else if (path === "/about" || path === "/product" || path === "/contact") {
        response.writeHead(200, { "ContentType": "text/html" })
        response.end(readFileSync(`pages${path}.html`, 'utf8'))
    } 
    else if (path === "/product.json") {
        response.writeHead(200, { "ContentType": "text/json" })
        response.end(readFileSync(`pages/${path}`, 'utf8'))
    } 
    else if (path == "/styles/light.css" ||  path === '/styles/home.css') {
        response.writeHead(200)
        response.end(readFileSync(`.${path}`, 'utf8'))
    }
    else {
        log(path)
        response.writeHead(404, { "ContentType": "text/html" })
        response.end(readFileSync('pages/404.html', 'utf8'))
    }
}).listen(1000, () => log("Sever started at http://127.0.0.1:1000"))