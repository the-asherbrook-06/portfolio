import { createSlice } from "@reduxjs/toolkit";

const initialState = { count: 0 }
const counter = createSlice({
    name: "counter",
    initialState: initialState,
    reducers: {
        increment: (state) => {
            if(state.count < 10)
                state.count += 1
        },
        decrement: (state) => {
            if(state.count > 0)
                state.count -= 1
        },
        reset: (state) => {
            state.count = 0
        },
        set: (state, action) => {
            state.count = action.payload
        },
    },
})

export const { increment, decrement, set, reset } = counter.actions
export default counter.reducer