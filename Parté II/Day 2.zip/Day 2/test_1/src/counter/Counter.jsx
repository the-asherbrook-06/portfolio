import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { increment, decrement, set, reset } from '../../slices/counterSlice'

import '../../style.css'

function Counter() {
    let selector = useSelector((state) => state.counter)
    let dispatch = useDispatch()

    function getValue() {
        return parseInt(prompt("Enter a Value: "))
    }

    return (
        <div className='display'>
            <div className='value'>Value: {selector.count}</div>
            <div className="controls">
                <button className='valueClass' onClick={() => dispatch(increment())}>
                    <span className="material-symbols-outlined">
                        add
                    </span>
                </button>
                <button className='valueClass' onClick={() => dispatch(decrement())}>
                    <span className="material-symbols-outlined">
                        remove
                    </span>
                </button>
                <button className='valueClass' onClick={() => dispatch(set(getValue()))}>
                    <span className="material-symbols-outlined">
                        edit
                    </span>
                </button>
                <button className='valueClass' onClick={() => dispatch(reset())}>
                    <span className="material-symbols-outlined">
                        history
                    </span>
                </button>
            </div>
        </div>
    )
}

export default Counter