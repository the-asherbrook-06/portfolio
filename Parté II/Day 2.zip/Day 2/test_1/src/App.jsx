import React from 'react'
import Counter from './counter/Counter'

function App() {
  return (
    <>
      <Counter></Counter>
    </>
  )
}

export default App
