// slices/blogSlice.jsx
import { createSlice } from "@reduxjs/toolkit";

const initialBlogState = [];

const blogs = createSlice({
    name: "blogs",
    initialState: initialBlogState,
    reducers: {
        addBlog: (state, action) => {
            state.push(action.payload);
        }
    }
});

export const { addBlog } = blogs.actions;
export default blogs.reducer;
