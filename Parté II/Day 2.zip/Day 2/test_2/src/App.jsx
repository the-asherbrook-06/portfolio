import React from 'react'
import { BrowserRouter, Routes, Route } from "react-router-dom"

import ViewPosts from './Pages/viewPosts'
import AddPosts from './Pages/addPosts'

import './Style/styles.css'
import './Style/light.css'

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/posts" element={<ViewPosts />} />
          <Route path="/create" element={<AddPosts />} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App