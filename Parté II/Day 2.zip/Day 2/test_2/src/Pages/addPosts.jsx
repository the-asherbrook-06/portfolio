import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addBlog } from '../../slices/blogSlice';
import { useNavigate } from 'react-router-dom';


function AddPosts() {
  const [blog, setBlog] = useState({
    id: Date.now(),
    title: "",
    content: "",
    author: "",
  });

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBlog((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = () => {
    dispatch(addBlog(blog));
    navigate('/posts');
  };

  const handleCancel = () => {
    navigate('/posts');
  };

  return (
    <div className="addPostContainer">
      <h1>Create New Post</h1>
      <div className="inputField">
        <label htmlFor="title">Title</label>
        <input type="text" id="title" name="title" value={blog.title} onChange={handleChange} />
      </div>
      <div className="inputField">
        <label htmlFor="author">Author</label>
        <input type="text" id="author" name="author" value={blog.author} onChange={handleChange} />
      </div>
      <div className="inputField">
        <label htmlFor="content">Content</label>
        <textarea id="content" name="content" rows="4" value={blog.content} onChange={handleChange}></textarea>
      </div>
      <button className="submitButton" onClick={handleSubmit}>Submit</button>
      &nbsp;
      <button className="submitButton" onClick={handleCancel}>Cancel</button>
    </div>
  );
}

export default AddPosts;
