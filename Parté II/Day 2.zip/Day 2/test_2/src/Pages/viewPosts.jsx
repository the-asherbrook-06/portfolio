import React from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';


function ViewPosts() {
  const selector = useSelector((state) => state.blogs);
  const navigate = useNavigate();

  const handleAddPosts = () => {
    navigate('/create');
  }

  return (
    <div className="viewPostsContainer">
      <h1>All Blog Posts</h1>
      <button className="submitButton" onClick={handleAddPosts}>Add Posts</button>
      <br />
      <br />
      {selector.map((blog) => {
        return (
          <div className="BlogCard" key={blog.id}>
            <div className="title">{blog.title}</div>
            <div className="author">By: {blog.author}</div>
            <div className="content">{blog.content}</div>
          </div>
        );
      })}
    </div>
  );
}

export default ViewPosts;
