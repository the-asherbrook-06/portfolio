
import { appendFileSync } from 'fs'

appendFileSync('timeLogFile.txt', Date().toLocaleString()+'\n')