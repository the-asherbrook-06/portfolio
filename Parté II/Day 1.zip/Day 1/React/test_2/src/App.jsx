import React, { useState } from 'react';
import Header from './components/Header';
import BlogList from './components/BlogList';
import BlogPost from './components/BlogPost';
import Footer from './components/Footer';

const App = () => {
  const [posts] = useState([
    {
      title: 'First Blog Post',
      excerpt: 'This is the first blog post...',
      content: 'This is the full content of the first blog post.',
    },
    {
      title: 'Second Blog Post',
      excerpt: 'This is the second blog post...',
      content: 'This is the full content of the second blog post.',
    },
  ]);

  const [selectedPost, setSelectedPost] = useState(null);

  const handleReadMore = (index) => setSelectedPost(posts[index]);
  const handleBack = () => setSelectedPost(null);

  return (
    <div>
      <Header />
      <div className="container my-4">
        {selectedPost ? (
          <BlogPost post={selectedPost} onBack={handleBack} />
        ) : (
          <BlogList posts={posts} onReadMore={handleReadMore} />
        )}
      </div>
      <Footer />
    </div>
  );
};

export default App;