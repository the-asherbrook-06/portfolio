import React from 'react';
import { Card, Button } from 'react-bootstrap';

const BlogPost = ({ post, onBack }) => {
  return (
    <Card>
      <Card.Body>
        <Card.Title>{post.title}</Card.Title>
        <Card.Text>{post.content}</Card.Text>
        <Button variant="secondary" onClick={onBack}>
          Back to Blogs
        </Button>
      </Card.Body>
    </Card>
  );
};

export default BlogPost;