import React from 'react';
import { Card, Button } from 'react-bootstrap';

const BlogList = ({ posts, onReadMore }) => {
  return (
    <div>
      {posts.map((post, index) => (
        <Card className="mb-3" key={index}>
          <Card.Body>
            <Card.Title>{post.title}</Card.Title>
            <Card.Text>{post.excerpt}</Card.Text>
            <Button onClick={() => onReadMore(index)}>Read More</Button>
          </Card.Body>
        </Card>
      ))}
    </div>
  );
};

export default BlogList;