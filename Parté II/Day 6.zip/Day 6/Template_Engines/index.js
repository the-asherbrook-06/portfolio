const {engine} = require('express-handlebars')
const express = require('express')
const path = require('path')
const app = express()

app.engine('hbs', engine({extname: 'hbs', defaultLayout: false}))

app.set('view engine', 'hbs')

app.use(express.json())
app.use(express.static(path.join(__dirname, "./public")))

app.get('/home', (request, response) => {
    let user = "Asher Brook"
    response.status(200).render('index', {user})
})

app.get('/about', (request, response) => {
    let arr = ["Hello", "Hóla", "Bonjoùr"]
    response.status(200).render('about', {arr})
})

app.get('/contact', (request, response) => {
    response.status(200).render('contact')
})

app.listen(1212, () => console.log("Server Started at http://127.0.01:1212"))