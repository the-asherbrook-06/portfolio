import Todo from "./Todo";

function App() {
    return (
        <Todo></Todo>
    )
}

export default App;