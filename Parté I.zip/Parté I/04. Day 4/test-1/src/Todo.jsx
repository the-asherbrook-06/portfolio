import React from "react";
import { useRef, useState } from "react";


function Todo() {
    const [input, setInput] = useState([])
    const refer = useRef()

    function handleClick() {
        setInput([...input, { id: Math.random(), task: refer.current.value }])
        refer.current.value = ""
    }

    function removeElement(idVal) {
        setInput(input.filter(i => i.id != idVal))
    }

    let style =
        `
        * {
            margin: 0;
            padding: 0;
        }

        #InputCard {
            background-color: beige;
            margin: 20px;
            padding: 20px;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            align-items: center;
            justify-content: center;
        }

        #InputCard .inputField {
            height: 3vh;
            width: 50vw;
            border-radius: 10px;
            border: 0.1px grey solid;
            background-color: azure;
            font-family: 'Segoe UI';
        }

        #InputCard .saveButton {
            height: 3vh;
            width: 25vw;
            border-radius: 10px;
            border: 0.1px grey solid;
            background-color: whitesmoke;
            font-family: 'Segoe UI';
        }

        #TaskList {
            background-color: beige;
            margin: 20px;
            padding: 20px;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            align-items: center;
            justify-content: center;
        }

        #TaskList .Tasks {
            background-color: bisque;
            height: 30px;
            width: 50vw;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            justify-content: start;
            font-family: 'Segoe UI';
            border-radius: 10px;
        }
    `

    return (
        <>
            <div id="InputCard">
                <input type="text" class="inputField" ref={refer} placeholder="  Tasks"/>
                <button class='saveButton' onClick={handleClick}>Save</button>
            </div>
            <div id="TaskList">
                    {input.map(i => {
                        return (
                            <div class="Tasks" key={i.id} onClick={() => removeElement(i.id)}>{i.task}</div>
                        )
                    })}
            </div>
            <style>
                {style}
            </style>
        </>
    )
}

export default Todo;
