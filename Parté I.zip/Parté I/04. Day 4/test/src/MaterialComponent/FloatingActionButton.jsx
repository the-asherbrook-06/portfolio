const FAB = ({ label, icon, action }) => {
    var style = `
    #FAB {
        box-shadow: 0.1px 2px 3px rgba(0, 0, 0, 0.5);
        background-color: antiquewhite;
        font-family: 'Segoe UI';
        justify-content: center;
        border-radius: 15px;
        height: fit-content;
        align-items: center;
        width: fit-content;
        font-size: large;
        position: fixed;
        display: flex;
        padding: 20px;
        border: none;
        bottom: 1vh;
        right: 1vw;
        gap: 5px;
    }

    #FAB:hover {
        box-shadow: 0.1px 3px 3px rgba(0, 0, 0, 0.5);
    }

    #FAB:active {
        box-shadow: 0.1px 1px 3px rgba(0, 0, 0, 0.5);
    }
    `

    return (
        <>
            <button id={'FAB'} onClick={action}>
                <span class="material-symbols-outlined">
                    {icon}
                </span>
                {label}
            </button>
            <style>
                {style}
            </style>
        </>
    )
}

export default FAB;