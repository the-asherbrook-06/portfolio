import { useState } from "react";

const Button = () => {
    const [data, setData] = useState(0)
    console.log("State: "+data)

    return (
        <div>
            <div>{data}</div>
            <button onClick={()=> setData((prev) => {
                return prev+1
            })}>Add One</button>
        </div>
    )
}

export default Button;