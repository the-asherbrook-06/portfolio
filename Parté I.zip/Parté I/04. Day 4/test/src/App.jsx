import Button from './MaterialComponent/Button.jsx'

function App() {
  return (
    <>
      <Button></Button>
    </>
  )
}

export default App