import React, { useState } from "react";
import "./App.css";

function App() {
  const [color, setColor] = useState("");

  const handleChange = (event) => {
    setColor(event.target.value);
  };

  const handleSubmit = () => {
    document.getElementById("color-box").style.backgroundColor = color;
  };

  return (
    <div className="App">
      <div id="color-box" className="color-box"></div>
      <input
        type="text"
        placeholder="Enter a color"
        value={color}
        onChange={handleChange}
        className="color-input"
      />
      <button onClick={handleSubmit} className="submit-button">
        Submit
      </button>
    </div>
  );
}   

export default App;