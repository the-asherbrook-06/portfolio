function Header() {
    return (
        <div class='header'>
            This is an Header    
        </div>
    )
}

function Footer() {
    return (
        <div class="footer">
            Hello, this is a Footer
        </div>
    )
}

function Content() {
    var data = [1,2,3,4,5]
    return (
        <div class='content'>
            <ul>
                {
                    data.map(i=> {
                        return(
                            <li key={'listItem'+i}>{i}</li>
                        )
                    })
                }
            </ul>
        </div>
    )
}

export { Header, Content, Footer };