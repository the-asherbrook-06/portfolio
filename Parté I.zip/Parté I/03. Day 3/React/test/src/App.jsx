import { Header, Content, Footer } from "./header"

function App() {
    return (
        <>
            <Header/>
            <Content/>
            <Footer/>
        </>
    )
}

export { App }