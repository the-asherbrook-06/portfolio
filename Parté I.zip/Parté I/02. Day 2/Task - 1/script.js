const hr = document.getElementsByClassName('hr')[0]
const min = document.getElementsByClassName('min')[0]
const sec = document.getElementsByClassName('sec')[0]

setInterval(() => {
    const date = new Date();
    hr.innerHTML = date.getHours();
    min.innerHTML = date.getMinutes();
    sec.innerHTML = date.getSeconds();
}, 1000)