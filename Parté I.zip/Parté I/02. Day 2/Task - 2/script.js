const Container = document.getElementById("container");
let clickCount = 0;

function updateContainer(content) {
    Container.innerHTML = content;
}

Container.addEventListener('click', () => {
    clickCount += 1;
    updateContainer(clickCount);
});

window.addEventListener('keypress', (e) => {
    if (e.key === " ") { 
        clickCount += 1;
        updateContainer(clickCount);
    }
});

window.addEventListener('keypress', (e) => {
    if (e.key === "r" || e.key === "R") {
        updateContainer("R");
        setTimeout(() => {
            clickCount = 0;
            updateContainer(clickCount);
        }, 500);
    }
});
