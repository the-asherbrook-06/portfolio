import { useState } from 'react';
import React from 'react'

function Form() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  function handleEmailChange(e) {
    setFormData({ ...formData, email: e.target.value })
  }

  function handlePassChange(e) {
    setFormData({ ...formData, password: e.target.value })
  }

  function display() {
    console.log(formData);
  }

  return (
    <div id='container' className='shadow-2xl'>
      <h1 contentEditable>Form</h1>
      <br />
      <table id='form'>
        <tbody>
          <tr>
            <td><input type="text" name='Email' onChange={(e) => handleEmailChange(e)} id='emailInput' placeholder='Email' /></td>
          </tr>
          <tr>
            <td><input type="password" name='Password' onChange={(e) => handlePassChange(e)} id='passwordInput' placeholder='Password' /></td>
          </tr>
          <tr>
            <td>
              <button id='SubmitButton' onClick={display} className='shadow-lg hover:shadow-xl active:shadow-sm'>Submit</button>
            </td>
          </tr>
        </tbody>
      </table>
      <br /><br />
      <div className='Output'>
        <div className="Email"></div>
      </div>
    </div>
  )
}

export default Form