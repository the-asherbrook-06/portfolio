import React from 'react'

function Home() {
  return (
    <div>
      <div className="bg-red-200 w-96 h-96 rounded-full flex items-center font-extralight  drop-shadow-2xl text-red-950 justify-center text- text-9xl">hello</div>
    </div>
  )
}

export default Home