function generateInput() {
    const options = ["rock", "paper", "scissors"];
    return options[Math.floor(Math.random() * 3)];
}

function checkWinner(player1, player2) {
    const outcomes = {
        rock: { scissors: 'player wins', rock: 'tie', paper: 'computer wins' },
        paper: { rock: 'player wins', paper: 'tie', scissors: 'computer wins' },
        scissors: { paper: 'player wins', scissors: 'tie', rock: 'computer wins' }
    };
    return outcomes[player1][player2] || 'Invalid input'; // Handle unexpected inputs
}


let userInput = prompt("Enter your Input [Rock, Paper, Scissors]").toLowerCase()
let computerInput = generateInput()


alert("User:           " + userInput + 
      "\nComputer:  "+computerInput+
      "\n\nStatus:        "+checkWinner(userInput, computerInput))