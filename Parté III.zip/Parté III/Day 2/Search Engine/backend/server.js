const course = require('./models/schema.js')
const { DB } = require('./DB/db.js')
const express = require('express')
const morgan = require('morgan')
const cors = require('cors')
const app = express()

app.use(express.json())
app.use(cors())

app.get('/api/v1/search', async (request, response) => {
  await DB('mongodb://localhost:27017/course')
  let Query = request.query.search
  let courseResult = await course.find({ title: { $regex: Query, $options: 'i' } })
  response.status(200).json(courseResult)
})

app.listen(2000, () => console.log("Server Started on http://localhost:2000"))