const mongoose = require('mongoose')

const DB = async (URI) => {
  try {
    await mongoose.connect(URI)
    console.log("MongoDB Connected Sucessfully")
  } catch (e) {
    console.log("MongoDB Connection ERROR: " + e)
  }
}

module.exports = { DB }