import axios from 'axios'
import { useState } from 'react'
import View from './View'
import React from 'react'

function Search() {
  const [data, setData] = useState([])
  const [value, setValue] = useState('')

  async function handleViews() {
    value.split(' ').forEach((i) => console.log(i))
    let APIResponse = await axios.get(`http://localhost:2000/api/v1/search?search=${value}`)
    setData(APIResponse.data)
  }

  function handleClick(e) {
    e.preventDefault()
    handleViews()
  }

  return (
    <>
      <div className="form-container">
        <form action="">
          <table>
            <tbody>
              <tr>
                <td><label htmlFor="query">Search: </label></td>
                <td><input type="text" id='query' onChange={(e) => setValue(e.target.value)} /></td>
              </tr>
              <tr>
                <td colSpan={2}><button value={'submit'} onClick={(e) => handleClick(e)}>Search</button></td>
              </tr>
            </tbody>
          </table>
        </form>
      </div>
      <div className="outputContainer">
        {data.map((i) => <View key={data.indexOf(i)} title={i.title} description={i.description} />)}
      </div>
    </>
  )
}

export default Search