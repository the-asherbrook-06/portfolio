const mongoose = require('mongoose')
const anime = require('./schema')

// Database connection
const connectDB = async () => {
  try {
    await mongoose.connect('mongodb://localhost:27017/anime')
    console.log("Mongo DB Connected Sucessfully")
  } catch (e) {
    console.log("ERROR: " + e)
  }
}
connectDB()

// CRUD OPERATIONS

// Read
async function getAnime(filter = {}) {
  try {
      const animes = await anime.find(filter);
      console.log('Animes found:', animes);
      return animes;
  } catch (error) {
      console.error('Error reading Animes:', error);
  }
}

const animeResult = getAnime({title: 'One Piece'})
console.log(animeResult);