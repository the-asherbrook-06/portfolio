const mongoose = require('mongoose')

const animeSchema = new mongoose.Schema({
  title: String,
  synopsis: String,
  description: {
    episodeCount: Number,
    genre: [String],
    ratings:  Number
  }
})

module.exports = mongoose.model('Anime', animeSchema)