const mongoose = require('mongoose')

const taskSchema = new mongoose.Schema({
  title: String,
  description: String,
  date: {
    created: Date,
    deadline: Date
  },
  tags: [String]
})

module.exports = mongoose.model('task', taskSchema)