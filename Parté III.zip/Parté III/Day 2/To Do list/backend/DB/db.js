const mongoose = require('mongoose')

const DB = async () => {
  try {
    await mongoose.connect('mongodb://localhost:27017/task')
    console.log('Database Connected')
  } catch (e) {
    console.log('Database Connection ERROR: ' + e)
  }
}



module.exports = { DB }