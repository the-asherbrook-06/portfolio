const { user, task } = require('./models/Schema.js');
const { DB } = require('./DB/db.js');
const express = require('express');
const morgan = require('morgan');
const cors = require('cors');

const app = express();

app.use(express.json());
app.use(morgan('dev'));
app.use(cors());


app.get('/api/v1/user/all', async (request, response) => {
  await DB();
  const queryResult = await user.find();
  response.status(200).json(queryResult);
});

app.post('/api/v1/user', async (request, response) => {
  await DB();
  const body = request.body;
  const queryResult = await user.insertMany(body);
  response.status(201).json(queryResult);
});

app.get('/api/v1/user/:userID', async (request, response) => {
  await DB();
  const { userID } = request.params;
  const queryResult = await user.findById(userID);
  if (!queryResult) {
    return response.status(404).json({ message: 'User not found' });
  }
  response.status(200).json(queryResult);
});

app.patch('/api/v1/user/:userID', async (request, response) => {
  await DB();
  const { userID } = request.params;
  const body = request.body;
  const queryResult = await user.findByIdAndUpdate(userID, { $set: body }, { new: true });
  if (!queryResult) {
    return response.status(404).json({ message: 'User not found' });
  }
  response.status(200).json(queryResult);
});

app.put('/api/v1/user/:userID', async (request, response) => {
  await DB();
  const { userID } = request.params;
  const body = request.body;
  const queryResult = await user.findByIdAndUpdate(userID, body, { new: true });
  if (!queryResult) {
    return response.status(404).json({ message: 'User not found' });
  }
  response.status(200).json(queryResult);
});

app.delete('/api/v1/user/:userID', async (request, response) => {
  await DB();
  const { userID } = request.params;
  const queryResult = await user.deleteOne({ _id: userID });
  if (queryResult.deletedCount === 0) {
    return response.status(404).json({ message: 'User not found' });
  }
  response.status(200).json({ message: 'User deleted' });
});

app.get('/api/v1/user/:userID/task/all', async (request, response) => {
  await DB()
  const userID = request.params.userID
  const queryResult = await task.find({ userID: userID })
  response.status(200).json(queryResult)
})

app.get('/api/v1/user/:userID/task/:taskID', async (request, response) => {
  await DB()
  const { userID, taskID } = request.params
  const queryResult = await task.findOne({ _id: taskID, userID: userID })
  response.status(200).json(queryResult)
})


app.get('/api/v1/user/:userID/task/:field/:value', async (request, response) => {
  await DB()
  const field = request.params.field
  const value = request.params.value
  const queryResult = await task.find().where(field).equals(value)
  response.status(200).json(queryResult)
})


app.post('/api/v1/user/:userID/task', async (request, response) => {
  await DB()
  const body = request.body
  body.userID = request.params.userID
  const queryResult = await task.insertMany(body)
  response.status(200).json(queryResult)
})


app.patch('/api/v1/user/:userID/task/:taskID', async (request, response) => {
  await DB()
  const body = request.body
  const taskID = request.params.taskID
  body.userID = request.params.userID
  const queryResult = await task.findByIdAndUpdate(taskID, { $set: body }, { new: true })
  response.status(200).json(queryResult)
})


app.put('/api/v1/user/:userID/task/:taskID', async (request, response) => {
  await DB()
  const body = request.body
  const taskID = request.params.taskID
  body.userID = request.params.userID
  const queryResult = await task.findByIdAndUpdate(taskID, body, { new: true })
  response.status(200).json(queryResult)
})


app.delete('/api/v1/user/:userID/task/:taskID', async (request, response) => {
  await DB()
  const taskID = request.params.taskID
  const queryResult = await task.deleteOne({ _id: taskID })
  response.status(200).json(queryResult)
})

app.listen(2000, () => console.log("Backend Server started at http://localhost:4040"));