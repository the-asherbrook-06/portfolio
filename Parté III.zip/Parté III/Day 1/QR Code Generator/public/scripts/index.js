let linkInput = document.getElementById('linkInput')
let submitBtn = document.getElementById('submitBtn')
let qrCode = document.getElementById('qrCode')

submitBtn.addEventListener('click', (e) => {
    e.preventDefault()
    if (linkInput.value) getQRCode()
    else alert("Enter a value for link")
})

// async function getQRCode() {
//     let response = await fetch('http://localhost:1212/qr', {
//         method: "POST",
//         headers: {
//             "Content-Type": "application/json"
//         },
//         body: JSON.stringify({ data: linkInput.value })
//     })
//     response = await response.json()
//     console.log(response)

//     let img = document.createElement("img")
//     img.src = response
//     qrCode.append(img)
// }

async function getQRCode() {
    let response = await fetch(`http://localhost:1212/qr?link=${linkInput.value}`)
    response = await response.json()
    console.log(response)

    let img = document.createElement("img")
    img.src = response
    qrCode.append(img)
}