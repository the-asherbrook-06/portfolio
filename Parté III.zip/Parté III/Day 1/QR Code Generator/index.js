const express = require('express')
const qr = require('qrcode')
const path = require("path")
const app = express()

app.use(express.json())
app.use(express.static(path.join(__dirname, "public")))

app.get('/home', (request, response) => {
    response.status(200).sendFile(path.join(__dirname, "views/index.html"))
})

app.get('/qr', async (request, response) => {
    let genQR = await qr.toDataURL(request.query.link)
    response.status(200).json(genQR)
})

app.post('/qr', async (request, response) => {
    let linkInput = request.body.data
    let genQR = await qr.toDataURL(linkInput)
    response.status(200).json(genQR)
})

app.listen(1214, () => console.log("Server started at http://localhost:1214"))