package com.finalproject.java_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
