package com.example.demo.service;

import com.example.demo.model.Cust;
import com.example.demo.repo.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;


@RestController
public class API {
    @Autowired
    private Repository repository;

    @GetMapping("/api/v1/spring")
    public Map<String, String> getHTML() {
        Map<String, String> map = new HashMap<>();
        map.put("name", "Spring");
        return map;
    }

    @PostMapping("/api/v1/spring/user")
    public Cust postData(@RequestBody Cust cust) {
        return repository.save(cust);
    }

    @GetMapping("/api/v1/spring/user")
    public List<Cust> getData() {
        return repository.findAll();
    }

    @GetMapping("/api/v1/spring/user/{id}")
    public Cust getById(@PathVariable String id) {
        return repository.findById(id).get();
    }

    @PutMapping("/api/v1/spring/user/{id}")
    public String updateById(@PathVariable String id, @RequestBody Cust cust) {
        Cust old = repository.findById(id).get();
        old.name = cust.name;
        old.email = cust.email;
        repository.save(old);
        return "Updated";

    }

    @DeleteMapping("/api/v1/spring/user/{id}")
    public String deleteById(@PathVariable String id) {
        repository.deleteById(id);
        return "Deleted";
    }
}
