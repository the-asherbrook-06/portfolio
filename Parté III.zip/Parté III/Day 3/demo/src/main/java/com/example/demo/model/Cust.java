package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document("customers")
public class Cust {
    @Id
    public String _id;

    public String name;
    public String age;
    public String email;
}
