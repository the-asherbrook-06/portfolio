const mongoose = require('mongoose')

const DB = async () => {
  try {
    mongoose.connect('mongodb://127.0.0.1:27017/task')
    console.log('DB Connected Sucessfully')
  } catch (e) {
    console.log("DB Connection ERROR: " + e)
  }
}

module.exports = { DB }