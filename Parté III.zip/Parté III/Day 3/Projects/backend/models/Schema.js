const mongoose = require('mongoose')

const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String
})

const taskSchema = new mongoose.Schema({
  userID: { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
  title: String,
  description: String,
  taskTag: String,
  taskGroup: String,
  date: {
    created: { type: Date, default: Date.now },
    deadline: Date,
  }
})

const user = mongoose.model('user', userSchema)
const task = mongoose.model('task', taskSchema)

module.exports = { user, task }