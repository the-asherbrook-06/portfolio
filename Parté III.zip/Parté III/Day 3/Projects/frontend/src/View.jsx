import axios from 'axios'
import React, { useState } from 'react'

function View({ task, updateUI }) {
  const [toggle, setToggle] = useState(false)

  const [Title, setTitle] = useState(task.title)

  const deleteTask = async (e, userID, id) => {
    e.preventDefault()
    try {
      await axios.delete(`http://localhost:4040/api/v1/user/${userID}/task/${id}`)
      updateUI(id)
    } catch (e) {
      console.log('Error deleting element: ' + e)
    }
  }

  const updateTask = async (e, userID, id) => {
    e.preventDefault()
    try {
      await axios.patch(`http://localhost:4040/api/v1/user/${userID}/task/${id}`, task)
      updateUI(id)
    } catch (e) {
      console.log('Error deleting element: ' + e)
    }
  }

  return (
    <>
      <div className="Tasks">
        <h2>{task.title}</h2>
        <p>{task.description}</p>
        <p>{task.taskTag}</p>
        <p>{task.date.deadline}</p>
        <button onClick={(e) => deleteTask(e, task.userID, task._id)}>Delete Task</button>
        <button onClick={() => setToggle(!toggle)}>Update Task</button>
        {
          toggle && <form action="">
            <input type="text" value={task.title} onChange={(e) => setTitle(e.target.value)} />
            <button onClick={(e) => updateTask(e, task.userID, task._id)}> Update</button>
          </form>
        }
      </div>
    </>
  )
}

export default View
