import React, { useEffect, useState } from 'react'
import axios from 'axios'

import View from './View'

function Task() {
  const [Tasks, setTasks] = useState([])
  const [Response, setResponse] = useState([])

  const [Title, setTitle] = useState('')
  const [Description, setDescription] = useState('')
  const [TaskTag, setTaskTag] = useState('')
  const [TaskGroup, setTaskGroup] = useState('')
  const [Deadline, setDeadline] = useState('')

  useEffect(() => {
    async function getData() {
      let response = await axios.get('http://localhost:4040/api/v1/user/6799a362583bb71b616292f5/task/all')
      setResponse(response.data)
    }
    getData()
  }, [Tasks])

  const handleClick = async (e) => {
    e.preventDefault()
    if (!Title || !Description)
      alert('Both Title and Description are required')
    else {
      try {
        const response = await axios.post('http://localhost:4040/api/v1/user/6799a362583bb71b616292f5/task/', {
          title: Title,
          description: Description,
          taskTag: TaskTag,
          TaskGroup: TaskGroup,
          date: {
            deadline: Deadline
          }
        })
        setTasks([Task, response.data])
      } catch (e) {
        console.log('ERROR: Insertion Failed: ' + e)
      }
    }
  }

  const updateUI = async (id) => {
      setResponse(Response.filter((task) => task._id != id))
  }

  return (
    <>
      <div className="addTaskContainer">
        <form action="">
          <table>
            <tbody>
              <tr>
                <td><label htmlFor="Title">Title: </label></td>
                <td><input type="text" id="Title" onChange={(e) => setTitle(e.target.value)} /></td>
              </tr>
              <tr>
                <td><label htmlFor="Description">Description</label></td>
                <td><input type="text" id='Description' onChange={(e) => setDescription(e.target.value)} /></td>
              </tr>
              <tr>
                <td><label htmlFor="TaskTag">Tag: </label></td>
                <td><select defaultValue="White" id="TaskTag" onChange={(e) => setTaskTag(e.target.value)}>
                  <option value="White">White</option>
                  <option value="Blue">Blue</option>
                  <option value="Green">Green</option>
                  <option value="Brown">Brown</option>
                </select></td>
              </tr>
              <tr>
                <td><label htmlFor="TaskGroup">Group: </label></td>
                <td><select id="TaskGroup" onChange={(e) => setTaskGroup(e.target.value)}>
                  <option value="Work">Work</option>
                  <option value="Home">Home</option>
                  <option value="Personal">Personal</option>
                </select></td>
              </tr>
              <tr>
                <td><label htmlFor="Deadline">Deadline: </label></td>
                <td><input type="datetime-local" id="Deadline" onChange={(e) => setDeadline(e.target.value)}/></td>
              </tr>
              <tr>
                <td colSpan={2}><button onClick={(e) => handleClick(e)}>Create Task</button></td>
              </tr>
            </tbody>
          </table>
        </form>
      </div>
      <div className="taskContainer">
        {
          Response.map((task) => <View key={task._id} task={task} updateUI={updateUI}/>)
        }
      </div>
    </>
  )
}

export default Task
